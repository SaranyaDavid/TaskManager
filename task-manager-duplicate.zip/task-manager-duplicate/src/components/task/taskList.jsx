import classes from "./tastList.module.css";
import { useContext } from "react";
import { TaskContext } from "../../store/taskcontext";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { RiDeleteBinLine } from "react-icons/ri";
import { FaBriefcase, FaUser } from "react-icons/fa";
import { FaEdit } from "react-icons/fa";

export default function TaskList({ tasks }) {
  const { markAsComplete, changePriority, deleteTask } =
    useContext(TaskContext);
  const param = useParams();
  const navigate = useNavigate();
  function handelEdit(id) {
    navigate("/edit-task/" + id);
  }

  const priorityColors = {
    Low: "#2ca22c",
    Medium: "orange",
    High: "#e673ba",
  };
  const commonStyle = (ele) => ({
    color: priorityColors[ele.priority],
    fontFamily: "'Satisfy', cursive",
    fontWeight: 700,
    fontStyle: "normal",
    fontSize: "22px",
  });
  return (
    <ul className={classes.outer}>
      {tasks || (tasks && tasks.length === 0) ? (
        tasks.map(
          (ele) =>
            !ele.deleted && (
              <li key={ele.taskId}>
                <article className={classes.article}>
                  <div className={classes.headerText}>
                    <div className={classes.head}>
                      <div className={classes.topper}>
                        <p>
                          {ele.category === "Work" && (
                            <FaBriefcase size={15}></FaBriefcase>
                          )}
                          {ele.category === "Personal" && (
                            <FaUser size={15}></FaUser>
                          )}
                        </p>
                        <h3>{ele.title}</h3>
                      </div>
                      {ele.status === "To-Do" && (
                        <button
                          onClick={() => changePriority(ele.taskId)}
                          style={commonStyle(ele)}
                        >
                          {ele.priority}
                        </button>
                      )}
                      {ele.status == "Completed" && (
                        <p style={commonStyle(ele)}>{ele.priority}</p>
                      )}
                    </div>
                    <p className={classes.textContent}>{ele.description}</p>
                    <div className={classes.sub}>
                      <ul>
                        {ele.subtask.subtask.map((data, index) => (
                          <li key={index}>
                            {index + 1} .{data}
                          </li>
                        ))}
                      </ul>
                      <p>{ele.date}</p>
                    </div>
                  </div>
                  <div className={classes.buttonBox}>
                    <button
                      className={classes.status}
                      onClick={() => markAsComplete(ele.taskId)}
                    >
                      {ele.status == "Completed" ? "Completed" : "Check off"}
                    </button>
                    <div className={classes.innerBtnbox}>
                      {ele.status == "To-Do" && (
                        // <button
                        //   onClick={() => handelEdit(ele.taskId)}
                        //   className={classes.status}
                        // >
                        //   Edit Task
                        // </button>
                        <FaEdit
                          onClick={() => handelEdit(ele.taskId)}
                          size={26}
                        ></FaEdit>
                      )}
                      <RiDeleteBinLine
                        onClick={() => deleteTask(ele.taskId)}
                        size={26}
                      />
                    </div>
                  </div>
                </article>
              </li>
            )
        )
      ) : (
        <li>
          <p className={classes.error}>No Task!</p>
        </li>
      )}
    </ul>
  );
}
