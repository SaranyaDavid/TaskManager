import { FaQrcode, FaStream, FaSlidersH } from "react-icons/fa";
import { useEffect, useState } from "react";
import classes from "./sidebar.module.css";
export default function SideButton({
  title,
  section,
  handleAddCategory,
  ...prop
}) {
  const [activeButton, setActiveButton] = useState([]);
  let values = [];
  try {
    values = JSON.parse(localStorage.getItem("filters"));
  } catch {
    console.log("Not set");
  }

  useEffect(() => {
    setActiveButton([values.Priority, values.Status, values.Category]);
  }, []);
  function handleClick(value) {
    console.log(title);
    handleAddCategory(value, title);
    const data = JSON.parse(localStorage.getItem("filters"));
    setActiveButton([data.Priority, data.Status, data.Category]);
    console.log("sdsdsd");
    console.log(activeButton);
  }
  return (
    <li>
      {title === "Status" && <FaQrcode />}
      {title === "Priority" && <FaStream />}
      {title === "Category" && <FaSlidersH />}
      <a href="#">{title}</a>
      <div className={classes.innerUl}>
        {section.map((value) => (
          <button
            key={value}
            className={
              activeButton.includes(value) ? classes.active_button : ""
            }
            onClick={() => handleClick(value)}
          >
            {value}
          </button>
        ))}
      </div>
    </li>
  );
}
