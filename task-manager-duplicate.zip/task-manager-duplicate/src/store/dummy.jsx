import { createContext } from "react";
import { useState, useEffect, useReducer } from "react";
import {
  getLocalStorageFilteredTasks,
  getLocalStoragePrimaryKey,
  setLocalStorageFilters,
  setLocalStoragePrimaryKey,
  getLocalStorageFilters,
  getLocalStorageTask,
  setLocalStorageTask,
} from "./localstoragelibrary";

export const TaskContext = createContext({
  task: [],
  completed: 0,
  pending: 0,
  filteredTask: [],
  addTask: () => {},
  updateTask: () => {},
  markAsComplete: () => {},
  changePriority: () => {},
  // countOfTasks: () => {},
  deleteTask: () => {},
  handleFilterButtonClick: () => {},
  filterItems: () => {},
});

function taskReducer(
  state = { task: [], filteredTask: [], completed: 0, pending: 0 },
  action
) {
  function countOfTasks(tasks) {
    const total = tasks.filter((ele) => !ele.deleted);
    const completed = tasks.filter(
      (ele) => ele.status === "Completed" && !ele.deleted
    );
    return {
      ...state,
      completed: completed.length,
      pending: total.length - completed.length,
    };
  }

  const filterItems = () => {
    const task = getLocalStorageTask();
    const filt = getLocalStorageFilters();
    if (filt.length > 0) {
      let tempItems = filt.map((selectedCategory) => {
        console.log(task);
        let temp = task.filter(
          (ele) =>
            ele.category == selectedCategory ||
            ele.priority == selectedCategory ||
            ele.status === selectedCategory
        );
        return temp;
      });
      const uniqueTasks = [...new Set(tempItems.flat())];
      localStorage.setItem("filteredTask", JSON.stringify(uniqueTasks));

      return {
        ...state,
        filteredTask: uniqueTasks,
      };
    } else {
      localStorage.setItem(
        "filteredTask",
        JSON.stringify(getLocalStorageTask())
      );

      return {
        ...state,
        filteredTask: getLocalStorageTask(),
      };
    }
  };
  if (action.type === "ADD_TASK") {
    const tasks = getLocalStorageTask();
    const taskId = Number(getLocalStoragePrimaryKey()) + 1;
    console.log(action);
    const newTask = {
      taskId,
      ...action.payload,
      subtask: { taskId, subtask: [...action.payload.subtask] },
    };
    let updateTask = [];
    if (tasks) {
      updateTask = [...tasks, newTask];
    } else {
      updateTask = [newTask];
    }
    setLocalStorageTask(updateTask);
    setLocalStoragePrimaryKey(taskId);
    filterItems();
    return {
      ...state,
      task: updateTask,
    };
  } else if (action.type === "UPDATE_TASK") {
    let task = getLocalStorageTask();
    const value = task.filter((ele) => ele.taskId != action.payload.id);
    const newValue = {
      taskId: action.payload,
      ...action.payload.data,
      subtask: {
        taskId: action.payload.id,
        subtask: [...action.payload.data.subtask],
      },
    };
    setLocalStorageTask([...value, newValue]);
    countOfTasks();
    filterItems();
    return {
      ...state,
      task: [...value, newValue],
    };
  } else if (action.type === "CHANGE_PRIORITY") {
    const priority = ["Low", "Medium", "High"];
    const allTasks = getLocalStorageTask();
    const index = allTasks.findIndex((task) => task.taskId === action.payload);
    const task = allTasks[index];
    let getPriority = priority.findIndex(
      (priority) => priority == task.priority
    );
    if (getPriority === 2) {
      getPriority = 0;
    } else {
      getPriority += 1;
    }
    const updatedTask = {
      ...task,
      priority: priority[getPriority],
    };
    allTasks[index] = updatedTask;
    setLocalStorageTask(allTasks);
    filterItems();
    countOfTasks();
    return {
      ...state,
      task: allTasks,
    };
  } else if (action.type === "DELETE") {
    const allTasks = getLocalStorageTask();
    const index = allTasks.findIndex((task) => task.taskId === action.payload);
    const task = allTasks[index];
    const data = {
      ...task,
      deleted: true,
    };
    allTasks[index] = data;
    setLocalStorageTask(allTasks);
    filterItems();
    return {
      ...state,
      task: allTasks,
    };
  } else if (action.type === "MARK_AS_COMPLETE") {
    const allTasks = getLocalStorageTask();
    const index = allTasks.findIndex((task) => task.taskId === action.payload);
    const task = allTasks[index];
    const updatedTask = {
      ...task,
      status: "Completed",
    };
    allTasks[index] = updatedTask;
    setLocalStorageTask([...allTasks]);
    countOfTasks();
    filterItems();
    return {
      ...state,
      task: allTasks,
    };
  } else if (action.type === "ADD_FILTER") {
    const filt = getLocalStorageFilters();
    const index = filt.findIndex((ele) => ele === action.payload);
    if (index === -1) {
      setLocalStorageFilters([...filt, action.payload]);
    } else {
      const data = filt.filter((ele) => ele != action.payload);
      setLocalStorageFilters([...data]);
    }
    filterItems();
  } else if (action.type === "COUNT") {
    if (state.task) {
      countOfTasks(state.task);
    }
  } else if (action.type === "INITIALIZE") {
    return {
      task: action.payload.tasks,
      filteredTask: action.payload.tasks,
      completed: 0,
      pending: 0,
      primaryKey: action.payload.primaryKey,
      filters: action.payload.filters,
    };
  }
}

export default function TaskContextProdiver({ children }) {
  const initialState = {
    task: [],
    filteredTask: getLocalStorageTask(),
    completed: 0,
    pending: 0,
  };
  const [taskList, dispatchTaskList] = useReducer(taskReducer, initialState);
  // const [taskList, setTaskList] = useState({
  //   filteredTask: getLocalStorageTask(),
  //   task: [],
  //   completed: 0,
  //   pending: 0,
  // });
  // useEffect(() => {
  //   const value = getLocalStoragePrimaryKey();
  //   const data = getLocalStorageTask();
  //   localStorage.setItem("filters", JSON.stringify([]));
  //   localStorage.setItem("filteredTask", JSON.stringify(data));
  //   // countOfTasks();
  //   localStorage.setItem("primaryKey", value);
  // }, []);
  useEffect(() => {
    // Fetch initial values asynchronously
    const fetchData = async () => {
      const primaryKey = getLocalStoragePrimaryKey();
      const tasks = getLocalStorageTask();
      const filters = getLocalStorageFilters();

      // Set initial values in local storage if not already set
      if (!primaryKey) {
        setLocalStoragePrimaryKey(0);
      }
      if (!tasks) {
        setLocalStorageTask([]);
      }
      if (!filters) {
        setLocalStorageFilters([]);
      }

      // Update state with fetched values
      dispatchTaskList({
        type: "INITIALIZE",
        payload: {
          tasks,
          primaryKey: primaryKey ? Number(primaryKey) : 0,
          filters: filters ? filters : [],
        },
      });
    };

    fetchData();
  }, []);

  function addTask(text) {
    dispatchTaskList({
      type: "ADD_TASK",
      payload: text,
    });
  }

  function updateTask(data, id) {
    dispatchTaskList({
      type: "ADD_TASK",
      payload: {
        id,
        data,
      },
    });
  }

  function changePriority(id) {
    dispatchTaskList({
      type: "CHANGE_PRIORITY",
      payload: id,
    });
  }

  function deleteTask(id) {
    dispatchTaskList({
      type: "DELETE",
      payload: id,
    });
  }

  function markAsComplete(id) {
    dispatchTaskList({
      type: "MARK_AS_COMPLETE",
      payload: id,
    });
  }

  function handleFilterButtonClick(value) {
    dispatchTaskList({
      type: "ADD_FILTER",
      payload: value,
    });
  }

  function countOfTasks() {
    dispatchTaskList({
      type: "COUNT",
    });
  }

  function getTaskById(id) {
    const data = localStorage.getItem("task");
    const task = JSON.parse(data);
    const index = task.findIndex((ele) => ele.taskId == id);
    const existingTask = task[index];
    return existingTask;
  }

  const ctxtValue = {
    task: getLocalStorageTask(),
    filteredTask: getLocalStorageFilteredTasks(),
    completed: taskList.completed,
    pending: taskList.pending,
    addTask: addTask,
    updateTask,
    markAsComplete,
    changePriority,
    countOfTasks,
    deleteTask,
    handleFilterButtonClick,
    // filterItems,
    getTaskById,
    // handleFindDeleted,
  };

  return (
    <TaskContext.Provider value={ctxtValue}>{children}</TaskContext.Provider>
  );
}

// function addTask(text) {
//   const tasks = getLocalStorageTask();
//   const taskId = Number(getLocalStoragePrimaryKey()) + 1;
//   const newTask = {
//     taskId,
//     ...text,
//     subtask: { taskId, subtask: [...text.subtask] },
//   };
//   let updateTask = [];
//   if (tasks) {
//     updateTask = [...tasks, newTask];
//   } else {
//     updateTask = [newTask];
//   }
//   setLocalStorageTask(updateTask);
//   setLocalStoragePrimaryKey(taskId);
//   setTaskList((pre) => {
//     return {
//       ...pre,
//       task: updateTask,
//     };
//   });
//   filterItems();
// }

// function updateTask(data, id) {
//   console.log("update" + id);
//   let task = getLocalStorageTask();
//   const value = task.filter((ele) => ele.taskId != id);
//   const newValue = {
//     taskId: id,
//     ...data,
//     subtask: { taskId: id, subtask: [...data.subtask] },
//   };
//   setLocalStorageTask([...value, newValue]);
//   setTaskList((ele) => {
//     return {
//       ...ele,
//       task: [...value, newValue],
//     };
//   });
//   filterItems();
// }

// function markAsComplete(id) {
//   const allTasks = getLocalStorageTask();
//   const index = allTasks.findIndex((task) => task.taskId === id);
//   const task = allTasks[index];
//   const updatedTask = {
//     ...task,
//     status: "Completed",
//   };
//   allTasks[index] = updatedTask;
//   setLocalStorageTask([...allTasks]);
//   setTaskList((prevState) => {
//     return {
//       ...prevState,
//       task: allTasks,
//     };
//   });
//   countOfTasks();
//   filterItems();
// }

// function changePriority(id) {
//   const priority = ["Low", "Medium", "High"];
//   const allTasks = getLocalStorageTask();
//   const index = allTasks.findIndex((task) => task.taskId === id);
//   const task = allTasks[index];
//   let getPriority = priority.findIndex(
//     (priority) => priority == task.priority
//   );
//   if (getPriority === 2) {
//     getPriority = 0;
//   } else {
//     getPriority += 1;
//   }
//   const updatedTask = {
//     ...task,
//     priority: priority[getPriority],
//   };
//   allTasks[index] = updatedTask;
//   setLocalStorageTask(allTasks);
//   setTaskList((pre) => {
//     return {
//       ...pre,
//       task: allTasks,
//     };
//   });
//   filterItems();
// }

// function countOfTasks() {
//   const total = taskList.task.filter((ele) => !ele.deleted);
//   const completed = taskList.task.filter(
//     (ele) => ele.status === "Completed" && !ele.deleted
//   );
//   setTaskList((ele) => {
//     return {
//       ...ele,
//       completed: completed.length,
//       pending: total.length - completed.length,
//     };
//   });
// }

// function deleteTask(id) {
//   const allTasks = getLocalStorageTask();
//   const index = allTasks.findIndex((task) => task.taskId === id);
//   const task = allTasks[index];
//   const data = {
//     ...task,
//     deleted: true,
//   };
//   allTasks[index] = data;
//   setLocalStorageTask(allTasks);
//   setTaskList((ele) => {
//     const tasks = [...ele.task];
//     const value = tasks.filter((work) => work.taskId != id);
//     return {
//       ...ele,
//       task: value,
//     };
//   });
//   console.log(taskList.task);
//   filterItems();
// }

// function getTaskById(id) {
//   const data = localStorage.getItem("task");
//   const task = JSON.parse(data);
//   const index = task.findIndex((ele) => ele.taskId == id);
//   const existingTask = task[index];
//   return existingTask;
// }

// const handleFilterButtonClick = (selectedCategory) => {
//   const filt = getLocalStorageFilters();
//   const index = filt.findIndex((ele) => ele === selectedCategory);
//   if (index === -1) {
//     setLocalStorageFilters([...filt, selectedCategory]);
//   } else {
//     const data = filt.filter((ele) => ele != selectedCategory);
//     setLocalStorageFilters([...data]);
//   }
//   filterItems();
// };
// function handleFindDeleted() {
//   const task = getLocalStorageTask();
//   let temp = task.filter((ele) => ele.deleted);
//   localStorage.setItem("filteredTask", JSON.stringify(temp));
//   setTaskList((prevState) => {
//     return {
//       ...prevState,
//       filteredTask: getLocalStorageTask(),
//     };
//   });
//   console.log(taskList.filteredTask);
// }
// const filterItems = () => {
//   const task = getLocalStorageTask();
//   const filt = getLocalStorageFilters();
//   if (filt.length > 0) {
//     let tempItems = filt.map((selectedCategory) => {
//       console.log(task);
//       let temp = task.filter(
//         (ele) =>
//           ele.category == selectedCategory ||
//           ele.priority == selectedCategory ||
//           ele.status === selectedCategory
//       );
//       return temp;
//     });
//     const uniqueTasks = [...new Set(tempItems.flat())];
//     localStorage.setItem("filteredTask", JSON.stringify(uniqueTasks));
//     setTaskList((prevState) => {
//       return {
//         ...prevState,
//         filteredTask: uniqueTasks,
//       };
//     });
//   } else {
//     localStorage.setItem(
//       "filteredTask",
//       JSON.stringify(getLocalStorageTask())
//     );
//     setTaskList((prevState) => {
//       return {
//         ...prevState,
//         filteredTask: getLocalStorageTask(),
//       };
//     });
//   }
// };
