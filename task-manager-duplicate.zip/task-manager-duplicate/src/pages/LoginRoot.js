import classes from "./RootLogin.module.css";
import image from "../images/login.png";
import { Outlet, redirect } from "react-router-dom";
import getLocalStorageUsers, {
  getLocalStorageUserID,
} from "../store/localstoragelibrary";

export default function LoginRoot() {
  return (
    <>
      <div className={classes.root}>
        <Outlet></Outlet>
        <img src={image}></img>
      </div>
    </>
  );
}

// export async function loginAction({ request }) {
//   console.log("hyujj");
//   const formData = await request.formData();
//   const data = {
//     userId: Number(getLocalStorageUserID()) + 1,
//     username: formData.get("user"),
//     password: formData.get("password"),
//     mobile: formData.get("mobile"),
//     agree: formData.get("check"),
//   };
//   const res = getLocalStorageUsers();
//   localStorage.setItem("user", JSON.stringify([...res, data]));
//   localStorage.setItem("primaryKeyUser", data.userId);
//   redirect("/task");
// }
